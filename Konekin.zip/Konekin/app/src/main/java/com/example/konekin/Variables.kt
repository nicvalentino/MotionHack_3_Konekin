package com.example.konekin

class Variables {
    companion object{
        var TICKET_AMOUNT = 20
        var POINT_AMOUNT = 35000
    }
}