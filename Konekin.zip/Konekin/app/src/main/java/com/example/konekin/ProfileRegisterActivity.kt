package com.example.konekin

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.konekin.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth

class ProfileRegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private lateinit var firebaseAuth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}