package com.example.konekin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.konekin.databinding.ActivityRewardSuccessBinding
import com.example.konekin.fragments.RewardFragment

class RewardSuccessActivity : AppCompatActivity() {

    private lateinit var binding : ActivityRewardSuccessBinding
    private val rewardFragment = RewardFragment()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRewardSuccessBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rewardSuccessButtonKlaimTicket.setOnClickListener {
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container, rewardFragment)
            transaction.commit()
        }

        binding.rewardSuccessBackbutton.setOnClickListener {
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container, rewardFragment)
            transaction.commit()
        }
    }
}