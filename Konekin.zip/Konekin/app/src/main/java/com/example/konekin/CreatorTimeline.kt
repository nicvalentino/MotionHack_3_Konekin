package com.example.konekin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CreatorTimeline : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_creator_timeline)
    }
}